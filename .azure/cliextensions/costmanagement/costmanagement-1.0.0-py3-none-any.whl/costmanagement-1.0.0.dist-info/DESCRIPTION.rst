Microsoft Azure CLI 'costmanagement' Extension
==========================================

This package is for the 'costmanagement' extension.
i.e. 'az costmanagement'

# Installation
Firstly, azure-cli must be installed. then `az extension add -n costmanagement`


# Commands

## Query
- az costmanagement query - Query the usage data for scope defined.

## Export - Manage cost export
- az costmanagement export create - Operation to create an export
- az costmanagement export update - Operation to update an export configuration
- az costmanagement export show/list - Operations to display export(s) information
- az costmanagement export delete - Operations to delete an existing export


.. :changelog:

Release History
===============

1.0.0
++++++
* Remove ADAL dependencies

0.3.0
++++++
* Add command ``az costmanagement show-operation-result``

0.2.1
++++++
* [BREAKING CHANGE] Remove the command ``az costmanagement query``. You can aggregate or filter the raw data from ``az costmanagement export`` instead.
* [BREAKING CHANGE] Remove the argument ``--dataset-grouping`` from the command ``az costmanagement export create/update``. You can group the raw data from ``az costmanagement export`` instead.

0.1.1
++++++
* Command group ``az costmanagement`` GA

0.1.0
++++++
* Initial release.
